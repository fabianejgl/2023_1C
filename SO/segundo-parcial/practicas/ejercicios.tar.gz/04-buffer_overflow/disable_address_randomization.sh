#!/usr/bin/env bash

echo 0 > /proc/sys/kernel/randomize_va_space