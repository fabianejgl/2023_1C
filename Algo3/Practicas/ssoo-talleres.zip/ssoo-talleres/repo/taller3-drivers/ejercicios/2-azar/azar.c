#include <linux/init.h>
#include <linux/module.h> // THIS_MODULE
#include <linux/kernel.h> // Kernel cosas
#include <linux/fs.h>     // File operations
#include <linux/cdev.h>   // Char devices
#include <linux/device.h> // Nodos filesystem
#include <linux/uaccess.h> // copy_to_user
#include <linux/slab.h>    // kmalloc
#include <linux/random.h>  // get_random_bytes

// Completar
#define DEVICE_NAME "azar"

struct cdev azar_dev;
static struct class *mi_class;
dev_t major;

static int num;

static ssize_t azar_read(struct file *filp, char __user *data, size_t s, loff_t *off) {
    unsigned int rand;
    get_random_bytes(&rand, sizeof(rand));
    rand = rand%num;


    char* buf = kmalloc(s+1,GFP_KERNEL);
    if(0 == snprintf(buf,s,"%u",rand)){
        kfree(buf);
        return -EPERM;
    }

    buf[s] = '\n';
    copy_to_user(data, buf, s+1);
    kfree(buf);

	return s;
}

static ssize_t azar_write(struct file *filp, const char __user *data, size_t s, loff_t *off) {
    char *buf = kmalloc(s+1, GFP_KERNEL);
    copy_from_user(buf,data,s);

    buf[s] = '\0';

    if(0 != kstrtoint(buf, 10, &num)){
        kfree(buf);
        return -EPERM;
    }
    
	kfree(buf);
    return s;
}

static struct file_operations azar_operaciones = {
	// Completar
	.owner = THIS_MODULE,
	.read = azar_read,
	.write = azar_write
};

static int __init azar_init(void) {
 	//Inicializarse como dispositivo. En el caso de este taller, nos ocuparemos exclusivamente de pro-
	// gramar char devices, por lo que tendremos que hacer #include <linux/cdev.h> y luego llamar
	// a la función
	cdev_init(&azar_dev, &azar_operaciones);
	//Conseguir un major y un minor. Conviene pedirle al kernel que nos reserve el major de manera dinámica, para lo cual podemos usar
	alloc_chrdev_region(&major, 0, 1, "SO-azar");
	//Luego tendremos que asignar los números al dispositivo que inicializamos previamente, mediante
	cdev_add(&azar_dev, major, 1);

	//creo archivo
	mi_class = class_create(THIS_MODULE, DEVICE_NAME);
	device_create(mi_class, NULL, major, NULL, DEVICE_NAME);	

	return 0;
}

static void __exit azar_exit(void) {
	//A la hora de descargar el módulo, solicitaremos la destrucción de los nodos llamando a
	device_destroy(mi_class, major);
	class_destroy(mi_class);
		//primero se hizo esto PORQUE se desasigna el archivo primero, y todavìa necesito el major

	//Al descargar el módulo deberemos liberar estos números, llamando a
	unregister_chrdev_region(major, 1);
	cdev_del(&azar_dev);
	printk(KERN_ALERT "Descarga del mòdulo azar\n");

}

// Completar
module_init(azar_init);
module_exit(azar_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("La banda de SO");
MODULE_DESCRIPTION("Generador de números al azar");