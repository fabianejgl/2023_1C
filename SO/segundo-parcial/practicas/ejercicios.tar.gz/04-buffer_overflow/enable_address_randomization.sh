#!/usr/bin/env bash

echo 2 > /proc/sys/kernel/randomize_va_space